<template>
    <div id="Software">
        大数据管理系统
    </div>
</template>
<script>
export default {
    name: 'Software',
    data(){
        return{

        }
    }
}
</script>
<style scoped>

</style>

