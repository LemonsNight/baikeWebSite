<template>
    <div id="smartTown">
        <p>
            智能化办公提升效率;流程人性化。
监管数据可模块化填报
智能一键式下单交易,后台自动跑批数据。
        </p>
        <p>
            区别于传统的O32、恒泰系统;
交易数据和要素智能录入;
人工只需符合,记录用户操作习惯;
提供算法支持,自动匹配和推荐资金现券相关信息;
为信用债客户提供信评模型分析
舆情监控功能。
        </p>
        <p>
            实时跟踪进度;催办、加急办;
实现全程电子化:电子签章、合同审批单等;
监管制度下,结构灵活设计;
可实现节点人员离柜审批、出差;
合规分控嵌入流程自动提示。

        </p>
        <p>
            银行间、交易所一键下单成交,避免重复;
自动生成成交单,直达会计岗,指令直接给托管行或账户,实现划款;
可催办。
模块化生成各监管机构所需报表，自动更新最新监管文件要求,提高对应模块给客户选择。

        </p>
        <p>
            后台地址：<a href="http://admin.tessai.cn/" target="_blank">Tessai资管后台系统</a>
        </p>
        <p>
            如果您需要申请使用该系统，请<router-link to="/contactus">联系我们</router-link>
        </p>
    </div>
</template>
<script>
export default {
    name: 'smartTown',
    data(){
        return{

        }
    },
    methods: {
    }
}
</script>
<style scoped>

</style>

